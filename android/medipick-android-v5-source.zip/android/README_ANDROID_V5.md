# MEDIPICK Android v5.0.0 — Debug build (iOS v1 source independent)

Android Studio Java native WebView shell reusing the verified Drive `MEDIPICK_v4_3_Android_Studio_Project.zip` source. Branded icons from Drive MEDIPICK PWA v5. Uses https://medipick.lexid.site/smart-store by default and restricts production URLs to medipick.lexid.site.

## Build
- Android Gradle Plugin 8.9.2, Gradle 8.11.1, JDK 17, compile/target API 35.
- From `android/` run `gradle :app:assembleDebug`.
- Debug APK: `android/app/build/outputs/apk/debug/app-debug.apk`.
- This APK is a **debug-signed development build, not Play Store-ready release**. Re-sign/rebuild with your own private release key for Play Console.
- Emulator Android API 35 with Google APIs recommended; verify online search, Google Maps key, background process, file chooser, deep links, permissions, SSL blocking.
- Authentication via Google must be initiated in external browser; browser cookies are not shared with WebView, so WebView signed-in experience is not guaranteed. Production TWA requires stable Google Play signing fingerprint + Digital Asset Links.
- Health/medical information must not be cached offline or treated as location-verified when `geocode_status != exact`.
- Any emulator test must report actual installed APK SHA-256 and screenshot/logcat evidence.

## Provenance
- Source Java and Android project from Drive `MEDIPICK_v4_3_Android_Studio_Project.zip` (source SHA-256 fb63dce01aa6050502712ad394ac87803b9808ae738731e84fad9436e4195d68).
- Brand icon from existing `MEDIPICK_PWA_ICON_512_V5_20261105.png`.
- Original test-only 17.9KB APK contains embedded demo.html and is NOT this production-connected build.
