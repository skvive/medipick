# MEDIPICK v4.3 — 설치형 웹앱(PWA) + Android 설치용 프로젝트

## 1. 구성

- `web/` — 이전 메디픽 v4.2 전체 디자인과 13개 HTML을 보존하고 모든 페이지에 PWA 설치 연결을 추가했습니다.
- `web/manifest.webmanifest`, `web/service-worker.js`, `web/offline.html`, `web/assets/pwa/` — 실제 설치형 PWA의 manifest·서비스워커·아이콘·설치 버튼.
- `android-app/` — Android Studio에서 빌드할 Java 네이티브 앱 프로젝트. 기존 MEDIPICK 서버와 HTTPS로 연결합니다.
- `server.py`, 기타 Python 모듈, 데이터/디자인/마케팅 문서 — 원본 v4.2 전체 백엔드·콘텐츠 유지.
- `tests/test_v43_mobile.py` — PWA·Android 보안과 구조 자동검증.

## 2. PWA 로컬 실행 / 배포

기존 `INSTALL_AND_RUN.cmd` 또는 `run_linux_mac.sh`를 실행합니다. Chrome에서 `http://localhost:8765`로 열면 PWA manifest와 service worker가 인식됩니다. 브라우저의 '앱 설치' 또는 '홈 화면에 추가'를 사용합니다. 설치 버튼은 브라우저가 `beforeinstallprompt`를 제공할 때만 표시됩니다.

**실제 휴대폰에서 접속하려면 반드시 인터넷에서 접근 가능한 HTTPS 서버가 필요합니다.** PC의 `localhost:8765`는 휴대폰의 로컬 서버가 아닙니다. 배포 서버는 도메인, TLS 인증서, 역방향 프록시, 접근제어, 개인정보 처리·운영 감사를 별도로 마련해야 합니다.

Service Worker는 API/건강기록/AI 상담/예약을 캐시하지 않습니다. 네트워크가 끊기면 의료기록 대신 일반적인 연결 안내를 제공합니다. 오프라인 데이터 편집·동기화 및 자동 충돌해결은 구현하지 않았습니다.

## 3. Android Studio 앱 빌드

1. `android-app/README_ANDROID.md` 지침에 따라 Android Studio에서 `android-app` 폴더를 프로젝트로 엽니다.
2. JDK 17 + Android SDK Platform 35 + Gradle 8.11.1을 설치합니다.
3. Sync 후 Build APK(s) 실행 → `android-app/app/build/outputs/apk/debug/app-debug.apk` 생성.
4. 설치하고 메디픽 HTTPS 서버 URL을 입력합니다. 에뮬레이터 디버그 빌드에서는 `http://10.0.2.2:8765` 테스트 가능.
5. 실기기는 HTTPS URL로 정상 서버에 접속해 검사합니다. 설치형 안드로이드 앱은 독립 로컬 서버를 탑재하지 않으므로 인터넷 연결이 필요합니다.

이 환경에는 Android SDK·Gradle 및 인터넷 접근 권한이 없어 **실제 APK/AAB 생성·에뮬레이터 설치·실기기 검증을 하지 못했습니다.** Android 앱 소스·빌드 프로젝트 및 재현 절차를 제공하는 상태입니다.

## 4. 운영 보안 및 상용화 제한

- 사진 기반 상담은 확진이 아니며 실제 인공지능 비전 모델 사용 시 동의·계약·인증이 필요합니다.
- 의료기관·의사·심야약국과 진료수가 등 데이터에는 가상 시연 샘플이 포함됩니다.
- Google OAuth/Blogger는 WebView의 임베디드 로그인이 제한됩니다. **Google 로그인이 필요한 운영서비스는 HTTPS 기반 PWA 또는 서명·Digital Asset Links가 검증된 Trusted Web Activity(TWA)를 권장**합니다. 현재 Android 소스는 기본 WebView 호스트이며 브라우저 전환을 제공합니다. 외부 브라우저 인증 상태를 WebView로 자동 연결하지 않습니다.
- 국내 의료광고, 환자정보, 영상 기록 및 건강보험 청구 데이터의 규제·보안 검증을 선행해야 합니다.
- Google Play 출시 전 Health apps declaration, 공개 개인정보처리방침, Data safety, 의료 콘텐츠 적합성·의료기기 관련 규제 여부를 확인하세요.

## 5. 테스트

`python -m unittest discover -s tests -p 'test_*.py' -q`를 실행합니다.

`python scripts/check_release_assets.py` 및 `python scripts/check_asset_graph.py`를 함께 실행하여 정적자산 누락을 검사합니다.

Android APK 실제 빌드는 Android Studio 혹은 프로젝트 루트의 `.github/workflows/android-debug.yml`을 GitHub 저장소에 등록하고 `workflow_dispatch`를 실행하여 수행합니다. GitHub Actions는 이 채팅에서 실행하지 않았습니다.
