# Google OAuth와 함께 배포하는 Android Trusted Web Activity(TWA) 경로

MEDIPICK의 공식 Google 로그인/Blogger OAuth는 WebView에 직접 로그인시키지 않습니다. 실제 배포용 Android 경험에는 Chrome 세션을 사용하는 TWA가 적합합니다.

1. MEDIPICK v4.3 PWA를 **운영 HTTPS 도메인**에 먼저 배포하고 `/manifest.webmanifest`가 HTTP 200인지 확인합니다.
2. Android 개발 PC에 JDK·Android SDK와 Bubblewrap 설치: `npm i -g @bubblewrap/cli`.
3. `bubblewrap init --manifest=https://<운영도메인>/manifest.webmanifest`로 TWA Android 프로젝트를 생성하고 앱 ID, 이름, 주소, 서명키를 지정합니다.
4. `bubblewrap build`로 APK/AAB를 빌드합니다.
5. 앱 서명 인증서의 SHA-256 fingerprint를 읽고 웹 도메인의 `https://<운영도메인>/.well-known/assetlinks.json`에 `delegate_permission/common.handle_all_urls`를 게시합니다.
6. PWA/앱 간 Digital Asset Links가 실제 기기에서 검증되면 전체화면 TWA로 실행되며, 실패 시 Chrome Custom Tab으로 폴백합니다.
7. Play App Signing을 쓰면 **Google Play가 배포에 사용하는 인증서 fingerprint**와 로컬 키를 구분해서 등록합니다.

템플릿 (`<...>` 자리는 실제 소유 정보로 교체):

```json
[{"relation":["delegate_permission/common.handle_all_urls"],"target":{"namespace":"android_app","package_name":"site.medipick.mobile","sha256_cert_fingerprints":["AA:BB:...(실제 서명 인증서 SHA-256)"]}}]
```

TWA는 서버 HTTPS 배포·앱 서명키가 정해져야 최종 빌드/검증할 수 있습니다. 이번 소스에는 임의 도메인 인증서 fingerprint를 만들거나 실제 Play 서명을 포함하지 않았습니다.
