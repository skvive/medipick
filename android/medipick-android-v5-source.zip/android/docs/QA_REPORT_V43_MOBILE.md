# MEDIPICK v4.3 설치형 웹앱 + Android 소스 검수 보고서

**판정일:** 2026-10-31 (KST) · **구성:** 기존 MEDIPICK v4.2 기준 정본 + PWA + Android Studio 소스

## 실제 확인된 검증

| 구분 | 확인 결과 |
|---|---|
| Python 기존 회귀 + 모바일 신규 | **163개 테스트 통과** (기존 151 + 신규 12; 기존 테스트 상속/중복 가능) |
| PWA 메타·아이콘·보안 | manifest 구조, 192/512 PNG, 13 HTML 페이지 연결, 서비스워커 API 캐시 제외 확인 |
| 실제 Python HTTP 서버 | **GET 9건 + HEAD 3건 성공**, 메인·AI 상담·나의 건강·PWA manifest/service worker/icons/offline·홈 API 확인 |
| 응답 캐시 정책 | API·HTML·서비스워커에 `Cache-Control: no-store` 단일 헤더 확인 |
| 정적 자산 | 파일 기반 분석 `check_release_assets.py` 0 missing, `check_asset_graph.py` 0 missing |
| JavaScript 구문 | Node.js `--check`: service-worker.js, install.js 정상 |
| Android 소스 | Gradle 프로젝트 / Manifest XML 유효 / 최소·대상 SDK / 파일 선택 / SSL 오류 거부 / WebView 보안 정책 코드 구조 검증 |
| 앱 아이콘 | Android adaptive 대체 mipmap 폴더별 PNG와 PWA 아이콘 생성 |
| 최종 ZIP | 압축파일 무결성, SHA-256 파일 재검증 및 별도 폴더 해제 후 Python 테스트 수행 예정 (출하 스크립트의 결과 참조) |

## 발견·수정 사항

1. PWA 도입 과정에서 응답 Cache-Control 헤더가 중복 전송되지 않도록 `headers_common`에 단일 헤더 처리 적용.
2. 13개 페이지에 일관된 설치 meta + manifest + install.js를 적용해 특정 서브페이지에서 설치 탐색이 누락되는 문제 방지.
3. Service Worker는 진단·처방·예약·계정·관리자 JSON/API 요청을 캐시하지 않도록 비적용. 개인정보를 오프라인에 보관하지 않음.
4. Android 앱에서 SSL 오류 계속 진행, 임의 `intent:` URL, 카메라/마이크 권한 자동 승인 등을 차단.

## 미검증/출시 전 필수

- **APK/AAB 실제 바이너리 빌드 미완료**: 이 환경에 Android SDK/Gradle이 없고 dl.google.com DNS 접근이 차단되어 Android 컴파일·설치·에뮬레이터·실기기 검증을 할 수 없음. Android Studio 프로젝트는 제공함.
- Android 기기 Chrome의 실제 '앱 설치' 경험, 현위치 사용, 카메라/사진 선택, WebView OAuth 동작 등의 E2E 테스트는 수행하지 못함.
- PWA/Android 앱은 **공개 HTTPS MEDIPICK 서버 배포가 선행**되어야 외부 휴대폰에서 사용 가능. `localhost`는 개발 PC 전용.
- Google/Blogger 실인증, 카카오·결제, 공식 HIRA/NHIS/의료 데이터, 실제 예약 및 건강정보 연동은 연결/운영 인증 미완료.
- 의료광고·민감정보·의학적 안전성·Google Play 건강 앱 등록 정책 및 배포 서명키 검증이 필요.

**출시 판정:** PWA·Android Studio 소스 통합·로컬 백엔드 검수 **조건부 PASS**; 실기기 APK, Google Play 및 실제 의료서비스 운영 **NOT READY**.
